// CONCEPT CAROUSEL · S01 E10 — "What if shadows could speak?"
// Nine code-drawn antiquarian plates on warm cotton rag:
// S01 the witness (cold open, no title) · S02 the echo · S03 the noon parley · S04 the heirloom ·
// S05 the deafening dark · S06 the witness at the podium · S07 the unseen self · S08 the turn ·
// S09 the title card (the question, spoken once, at the end).
// Every cut and subtitle phrase is keyed to the narration through wd()/cut(); no second-based cuts.
import { W, H, clamp, lerp, eo, eio, eback, rr, circ, poly, hash, rng, TAU, mixc } from './core/lib.js';
import { wd, cut, T } from './core/timing.js';

const COL = {
  linen: '#F5EFEB', vellum: '#EAE0D0', ink: '#1E1813', sepia: '#5C5248',
  terra: '#C2593F', amber: '#D9822B', ivory: '#FAF7F0', brass: '#C89D42', umber: '#2B1F17',
  wood: '#6E4A31', woodD: '#3A2518', brassD: '#8A6A2F', brassL: '#E7C57C', iron: '#3B3630',
  copper: '#A65E3A', copperL: '#D08A5E', snow: '#F2EADF', night: '#1C1712',
  cream: '#F7E9C9', butter: '#E8C76A', shadow: '#241C16', shadow2: '#3A2C22',
  dusk: '#8C6A4A', wall: '#B99A78', olive: '#6E6A45', oliveD: '#4A4730',
};
const F = { serif: '"Instrument Serif"', gara: '"EB Garamond"', mono: '"JetBrains Mono"', sans: 'Inter' };
const BADGE = { x: W / 2, y: 120, w: 520, h: 64 };
// Full-bleed art: the old 872-wide plate is extended to a 9:16 sheet and scaled
// to the frame. No mount, no border, no letterbox — the illustration is the page.
const ART = { x: 104, y: 0, w: 872, h: 1550.22 };
const SS = W / ART.w;
const TAG_Y = 1460;

const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const font = (c, size, fam = F.serif, weight = 400, style = 'normal', ls = 0) => {
  c.font = `${style} ${weight} ${size}px ${fam}`; c.letterSpacing = `${ls}px`;
};
const tw = (c, s, size, fam = F.serif, weight = 400, style = 'normal', ls = 0) => {
  c.save(); font(c, size, fam, weight, style, ls); const w = c.measureText(s).width; c.restore(); return w;
};
const fit = (c, s, maxW, size, fam = F.serif, weight = 400, style = 'normal', ls = 0, min = 18) => {
  const w = tw(c, s, size, fam, weight, style, ls); return w > maxW ? Math.max(min, size * maxW / w) : size;
};
function txt(c, s, x, y, o = {}) {
  const { size = 40, fam = F.serif, weight = 400, style = 'normal', col = COL.ink, align = 'center', base = 'middle', ls = 0, alpha = 1 } = o;
  c.save(); c.globalAlpha = alpha; font(c, size, fam, weight, style, ls);
  c.fillStyle = col; c.textAlign = align; c.textBaseline = base; c.fillText(s, x, y); c.restore();
}

// ── the one sheet of paper every plate is printed on ─────────────────────────────────────────────
let _paper = null;
function paper() {
  if (_paper) return _paper;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const x = cv.getContext('2d');
  x.fillStyle = COL.linen; x.fillRect(0, 0, W, H);
  const g = x.createRadialGradient(W * 0.5, H * 0.34, 60, W * 0.5, H * 0.46, Math.max(W, H) * 0.78);
  g.addColorStop(0, 'rgba(250,247,240,0.72)'); g.addColorStop(0.45, 'rgba(245,239,235,0.10)'); g.addColorStop(1, 'rgba(190,148,100,0.14)');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  const r = rng(29);
  for (let i = 0; i < 10; i++) {
    const cx = r() * W, cy = r() * H, rad = 120 + r() * 380;
    const sg = x.createRadialGradient(cx, cy, 0, cx, cy, rad);
    sg.addColorStop(0, `rgba(176,136,86,${0.016 + r() * 0.022})`); sg.addColorStop(1, 'rgba(176,136,86,0)');
    x.fillStyle = sg; x.fillRect(cx - rad, cy - rad, rad * 2, rad * 2);
  }
  for (let i = 0; i < 15000; i++) {
    const px = r() * W, py = r() * H, s = 0.4 + r() * 1.4, a = 0.012 + r() * 0.045;
    x.fillStyle = r() > 0.48 ? `rgba(92,72,52,${a})` : `rgba(255,252,246,${a * 1.5})`;
    x.fillRect(px, py, s, s);
  }
  for (let i = 0; i < 300; i++) {
    const px = r() * W, py = r() * H, len = 6 + r() * 30, an = r() * TAU;
    x.strokeStyle = `rgba(120,94,68,${0.018 + r() * 0.03})`; x.lineWidth = 0.6;
    x.beginPath(); x.moveTo(px, py);
    x.quadraticCurveTo(px + Math.cos(an) * len * 0.55 + (r() - 0.5) * 5, py + Math.sin(an) * len * 0.55 + (r() - 0.5) * 5, px + Math.cos(an) * len, py + Math.sin(an) * len);
    x.stroke();
  }
  _paper = cv; return cv;
}
function bg(c) { c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.drawImage(paper(), 0, 0); c.restore(); }

// ── shared furniture ─────────────────────────────────────────────────────────────────────────────
function gearMark(c, cx, cy, r, rot, a = 1) {
  c.save(); c.translate(cx, cy); c.rotate(rot); c.globalAlpha = a;
  c.strokeStyle = COL.brass; c.lineWidth = Math.max(2, r * 0.16);
  for (let i = 0; i < 8; i++) { const t = i * TAU / 8; c.beginPath(); c.moveTo(Math.cos(t) * r * 0.8, Math.sin(t) * r * 0.8); c.lineTo(Math.cos(t) * r * 1.35, Math.sin(t) * r * 1.35); c.stroke(); }
  circ(c, 0, 0, r * 0.8); c.stroke();
  circ(c, 0, 0, r * 0.34); c.fillStyle = COL.brass; c.fill();
  c.restore();
}
function badge(c, t = 0) {
  const { x, y, w, h } = BADGE;
  c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
  c.fillStyle = 'rgba(43,31,23,0.14)'; rr(c, x - w / 2 + 3, y - h / 2 + 6, w, h, 4); c.fill();
  c.fillStyle = COL.ivory; rr(c, x - w / 2, y - h / 2, w, h, 3); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3; rr(c, x - w / 2, y - h / 2, w, h, 3); c.stroke();
  c.strokeStyle = 'rgba(30,24,19,0.22)'; c.lineWidth = 2; rr(c, x - w / 2 + 6, y - h / 2 + 6, w - 12, h - 12, 2); c.stroke();
  gearMark(c, x - w / 2 + 42, y, 11, 0.2 + t * 0.55, 1);
  txt(c, 'CONCEPT CAROUSEL · S01 E10', x - w / 2 + 72, y + 1, { size: 22, fam: F.mono, weight: 700, ls: 1.8, align: 'left' });
  c.restore();
}
function loopMark(c, cx, cy, r, col, a = 1) {
  c.save(); c.globalAlpha = a; c.strokeStyle = col; c.lineWidth = 2.6;
  c.beginPath(); c.arc(cx, cy, r, Math.PI * 0.25, Math.PI * 1.82); c.stroke();
  const an = Math.PI * 1.82;
  const ax = cx + Math.cos(an) * r, ay = cy + Math.sin(an) * r;
  c.beginPath(); c.moveTo(ax - 4, ay - 6); c.lineTo(ax + 3, ay + 1); c.lineTo(ax - 6, ay + 5); c.stroke();
  c.restore();
}
function cornerBracket(c, x, y, dx, dy, s) {
  c.save(); c.strokeStyle = COL.brass; c.lineWidth = 7; c.lineCap = 'square';
  c.beginPath(); c.moveTo(x + dx * s, y); c.lineTo(x, y); c.lineTo(x, y + dy * s); c.stroke();
  c.strokeStyle = rgba(COL.ink, 0.75); c.lineWidth = 2; c.stroke();
  c.fillStyle = COL.brassD; circ(c, x + dx * 13, y + dy * 13, 3.2); c.fill();
  c.restore();
}
const brassGrad = (c, x0, y0, x1, y1) => {
  const g = c.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, COL.brassD); g.addColorStop(0.3, COL.brassL); g.addColorStop(0.62, COL.brass); g.addColorStop(1, '#7A5A26'); return g;
};
const copperGrad = (c, x0, y0, x1, y1) => {
  const g = c.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, '#7C4128'); g.addColorStop(0.28, COL.copperL); g.addColorStop(0.55, COL.copper); g.addColorStop(1, '#6E3722'); return g;
};

// ── plates, tags, subtitles ──────────────────────────────────────────────────────────────────────
function stage() { return ART; }
// a warm scrim under the caption block so ivory type reads on any plate
function foot(c) {
  c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
  const g = c.createLinearGradient(0, 1210, 0, H);
  g.addColorStop(0, 'rgba(20,16,12,0)');
  g.addColorStop(0.42, 'rgba(20,16,12,0.30)');
  g.addColorStop(1, 'rgba(20,16,12,0.74)');
  c.fillStyle = g; c.fillRect(0, 1210, W, H - 1210);
  c.restore();
}
function plateTag(c, text, y = 1332) {
  c.save(); c.shadowColor = 'rgba(20,16,12,0.65)'; c.shadowBlur = 7; c.shadowOffsetY = 2;
  txt(c, text, 540, y, { size: 17, fam: F.mono, weight: 700, col: 'rgba(231,197,124,0.86)', ls: 3.6 });
  c.restore();
}
function tag(c, text, col = COL.ink, k = 1, y = TAG_Y) {
  if (k <= 0) return;
  c.save(); const e = eo(clamp(k));
  c.globalAlpha = clamp(k * 1.2); c.translate(0, (1 - e) * 22);
  if (col === COL.ivory) { c.shadowColor = 'rgba(20,16,12,0.7)'; c.shadowBlur = 12; c.shadowOffsetY = 3; }
  txt(c, text, 540, y, { size: 54, fam: F.gara, weight: 600, col, ls: 1.5 });
  c.restore();
}
function fig(c, text, y = 1372, o = {}) {
  const { dark = false } = o;
  if (dark) {
    const w = tw(c, text, 18, F.mono, 500, 'normal', 2.2) + 40;
    c.save(); c.fillStyle = 'rgba(20,16,12,0.62)'; rr(c, 540 - w / 2, y - 17, w, 34, 3); c.fill();
    c.strokeStyle = 'rgba(250,247,240,0.18)'; c.lineWidth = 1.4; rr(c, 540 - w / 2, y - 17, w, 34, 3); c.stroke(); c.restore();
  }
  txt(c, text, 540, y, { size: 18, fam: F.mono, weight: 500, col: dark ? COL.ivory : COL.sepia, ls: 2.2, alpha: dark ? 0.88 : 0.92 });
}
const PHRASES = {
  0: [[0, 3], [3, 5], [5, 8]],
  1: [[0, 3], [3, 6], [6, 10], [10, 14]],
  2: [[0, 2], [2, 5], [5, 9], [9, 12]],
  3: [[0, 3], [3, 6], [6, 9]],
  4: [[0, 3], [3, 4], [4, 10]],
  5: [[0, 3], [3, 6], [6, 9]],
  6: [[0, 3], [3, 7], [7, 10], [10, 14]],
  7: [[0, 4], [4, 8], [8, 13]],
};
const wordsOf = (li) => T.words.filter((q) => q.line === li && /[A-Za-z0-9]/.test(q.w));
function subs(c, li, t, yc = 1600) {
  const ws = wordsOf(li); if (!ws.length) return;
  const ph = PHRASES[li]; if (!ph) return;
  let pi = -1;
  for (let i = 0; i < ph.length; i++) if (t >= ws[Math.min(ph[i][0], ws.length - 1)].s - 0.03) pi = i;
  if (pi < 0) return;
  const [a, b] = ph[pi];
  const lastE = Math.max(...ws.slice(a, b).map((q) => q.e));
  if (t > lastE + 0.45) return;
  const words = ws.slice(a, b).map((q) => q.w.toUpperCase().replace(/[—–]/g, '·'));
  const size = 58, gap = 22, maxW = 930, lineH = 74;
  const widths = words.map((s) => tw(c, s, size, F.gara, 600, 'normal', 1));
  const lineW = (i, j) => widths.slice(i, j).reduce((x, y) => x + y, 0) + gap * (j - i - 1);
  let split = words.length, best = Infinity;
  for (let k = 1; k < words.length; k++) {
    const w1 = lineW(0, k), w2 = lineW(k, words.length);
    if (w1 <= maxW && w2 <= maxW) { const sc = Math.max(w1, w2); if (sc < best) { best = sc; split = k; } }
  }
  const rows = split < words.length ? [[0, split], [split, words.length]] : [[0, words.length]];
  const y0 = yc - (rows.length - 1) * lineH / 2;
  const active = ws.findIndex((q, i) => i >= a && i < b && t >= q.s - 0.04 && t < q.e + 0.02) - a;
  const fade = clamp((t - ws[a].s + 0.10) / (3 / 24));
  const pin = eo(clamp((t - ws[a].s + 0.10) / 0.14));
  c.save(); c.globalAlpha = fade; c.translate(0, (1 - pin) * 9);
  rows.forEach(([i0, i1], ri) => {
    const rowW = lineW(i0, i1);
    let x = 540 - rowW / 2;
    const y = y0 + ri * lineH;
    for (let i = i0; i < i1; i++) {
      const w = widths[i], q = ws[a + i], isA = i === active, spoken = t >= q.s - 0.02;
      const pop = isA ? 1 + 0.07 * Math.max(0, 1 - (t - q.s) / 0.15) : 1;
      c.save();
      if (isA) { c.translate(x + w / 2, y); c.scale(pop, pop); c.translate(-(x + w / 2), -y); }
      if (isA) {
        c.fillStyle = COL.terra; rr(c, x - 14, y - 38, w + 28, 76, 7); c.fill();
        c.fillStyle = rgba(COL.umber, 0.18); rr(c, x - 14, y + 28, w + 28, 7, 3); c.fill();
      }
      txt(c, words[i], x + w / 2, y, { size, fam: F.gara, weight: 600, ls: 1, col: isA ? COL.ivory : (spoken ? COL.ivory : 'rgba(247,233,201,0.48)') });
      c.restore();
      x += w + gap;
    }
  });
  c.restore();
}

// ── the shadow kit: silhouettes, projected shadows, speech ──────────────────────────────────────
function personShape(c, pose = 'stand', hat = true) {
  c.beginPath();
  if (pose === 'walk') {
    c.moveTo(-20, -86); c.lineTo(-46, -4); c.lineTo(-26, -4); c.lineTo(-4, -86);
    c.moveTo(4, -86); c.lineTo(20, -4); c.lineTo(40, -4); c.lineTo(22, -86);
  } else if (pose === 'sit') {
    c.moveTo(-26, -88); c.lineTo(-42, -46); c.lineTo(30, -46); c.lineTo(24, -88);
    c.moveTo(18, -52); c.lineTo(34, -4); c.lineTo(52, -4); c.lineTo(38, -52);
  } else if (pose === 'turn') {
    c.moveTo(-18, -88); c.lineTo(-30, -4); c.lineTo(-10, -4); c.lineTo(2, -88);
    c.moveTo(8, -88); c.lineTo(26, -4); c.lineTo(46, -4); c.lineTo(26, -88);
  } else {
    c.moveTo(-22, -88); c.lineTo(-26, -4); c.lineTo(-6, -4); c.lineTo(-2, -88);
    c.moveTo(2, -88); c.lineTo(6, -4); c.lineTo(26, -4); c.lineTo(22, -88);
  }
  c.moveTo(-42, -150);
  c.quadraticCurveTo(-54, -118, -40, -78);
  c.lineTo(40, -78);
  c.quadraticCurveTo(54, -118, 42, -150);
  c.quadraticCurveTo(24, -168, 0, -168);
  c.quadraticCurveTo(-24, -168, -42, -150);
  c.closePath();
  if (pose === 'walk') {
    c.moveTo(-38, -146); c.quadraticCurveTo(-68, -120, -54, -90); c.lineTo(-42, -94); c.quadraticCurveTo(-52, -118, -30, -142); c.closePath();
    c.moveTo(38, -146); c.quadraticCurveTo(64, -124, 58, -96); c.lineTo(46, -98); c.quadraticCurveTo(50, -122, 30, -142); c.closePath();
  } else if (pose === 'turn') {
    c.moveTo(-38, -148); c.quadraticCurveTo(-60, -124, -50, -94); c.lineTo(-38, -98); c.quadraticCurveTo(-46, -122, -28, -144); c.closePath();
    c.moveTo(40, -146); c.quadraticCurveTo(56, -122, 48, -96); c.lineTo(38, -100); c.quadraticCurveTo(46, -124, 30, -144); c.closePath();
  } else if (pose === 'sit') {
    c.moveTo(-38, -148); c.quadraticCurveTo(-58, -126, -48, -98); c.lineTo(-36, -102); c.quadraticCurveTo(-46, -126, -28, -146); c.closePath();
    c.moveTo(40, -146); c.quadraticCurveTo(58, -128, 54, -106); c.lineTo(42, -108); c.quadraticCurveTo(46, -128, 30, -144); c.closePath();
  } else {
    c.moveTo(-38, -148); c.quadraticCurveTo(-58, -126, -50, -98); c.lineTo(-38, -102); c.quadraticCurveTo(-46, -126, -28, -146); c.closePath();
    c.moveTo(40, -146); c.quadraticCurveTo(58, -126, 50, -98); c.lineTo(38, -102); c.quadraticCurveTo(46, -126, 30, -146); c.closePath();
  }
  c.rect(-11, -174, 22, 16);
  c.moveTo(28, -192); c.arc(0, -192, 28, 0, TAU);
  if (hat) {
    c.moveTo(40, -216); c.ellipse(0, -216, 40, 7, 0, 0, TAU);
    c.rect(-24, -246, 48, 32);
  }
}
function person(c, x, baseY, s, o = {}) {
  const { col = COL.ink, a = 1, pose = 'stand', flip = false, hat = true, rim = true } = o;
  c.save(); c.translate(x, baseY); c.scale(s * (flip ? -1 : 1), s); c.globalAlpha = a;
  c.fillStyle = 'rgba(43,31,23,0.20)';
  c.beginPath(); c.ellipse(8, 2, 44, 8, 0, 0, TAU); c.fill();
  if (rim) {
    c.save(); c.translate(-3, -2); c.fillStyle = 'rgba(217,130,43,0.55)'; personShape(c, pose, hat); c.fill(); c.restore();
  }
  c.fillStyle = col; personShape(c, pose, hat); c.fill();
  c.strokeStyle = 'rgba(30,24,19,0.6)'; c.lineWidth = 2.2; c.stroke();
  c.restore();
}
function speechRings(c, x, y, r0, n, t, col = COL.ivory, a = 0.85, dir = 1) {
  c.save();
  for (let i = 0; i < n; i++) {
    const ph = (t * 1.25 + i / n) % 1;
    const rr = r0 + ph * 46;
    c.globalAlpha = a * (1 - ph) * 0.95;
    c.strokeStyle = col; c.lineWidth = 4.4 * (1 - ph * 0.4);
    const mid = dir > 0 ? 0 : Math.PI;
    c.beginPath(); c.arc(x, y, rr, mid - 0.55, mid + 0.55); c.stroke();
  }
  c.restore();
}
function wallShadow(c, x, baseY, s, rot, pose, t, o = {}) {
  c.save(); c.translate(x, baseY); c.rotate(rot); c.scale(s * 1.12, s * 1.55);
  // a soft penumbra, then the umbra: the wall's texture must show through
  c.globalAlpha = (o.a ?? 0.62) * 0.30; c.fillStyle = o.col || COL.shadow;
  c.save(); c.translate(5, 2); c.scale(1.04, 1.02); personShape(c, pose, o.hat === true); c.fill(); c.restore();
  c.globalAlpha = o.a ?? 0.62; c.fillStyle = o.col || COL.shadow;
  personShape(c, pose, o.hat === true); c.fill();
  if (o.edge) {
    // rim the body only: stroking the hat brim would read as a floating halo
    c.save();
    c.beginPath(); c.rect(-220, -206, 440, 620); c.clip();
    personShape(c, pose, o.hat === true);
    c.globalAlpha = 1; c.strokeStyle = o.edge; c.lineWidth = 2 / Math.max(0.4, s * 1.2); c.stroke();
    c.restore();
  }
  const m = c.getTransform();
  const head = m.transformPoint(new DOMPoint(0, -192));
  if (o.mouth !== false) {
    // the mouth sits in the lower third of the head so it never reads as a second eye
    c.globalAlpha = 1; c.fillStyle = o.mouthCol || COL.ivory;
    c.beginPath(); c.ellipse(4, -178, 12, 5.4, 0, 0, TAU); c.fill();
    c.fillStyle = o.col || COL.shadow;
    c.beginPath(); c.ellipse(4, -178, 7, 2.4, 0, 0, TAU); c.fill();
  }
  c.restore();
  if (o.rings !== false) {
    // map the head back into the caller's coordinate space (scenes are translated by PLATE_DY)
    const p = c.getTransform().inverse().transformPoint(new DOMPoint(head.x, head.y));
    speechRings(c, p.x + (o.ringDx ?? 16), p.y + (o.ringDy ?? -2), o.r0 ?? 28, o.rn ?? 4, t, o.ringCol || COL.ivory, o.ringA ?? 0.8, o.ringDir ?? 1);
  }
  return head;
}
function groundShadow(c, x, y, s, rot, pose, t, o = {}) {
  c.save(); c.translate(x, y); c.rotate(rot); c.scale(s * 1.5, s * 0.55);
  c.globalAlpha = (o.a ?? 0.72) * 0.34; c.fillStyle = o.col || COL.shadow;
  c.save(); c.translate(8, 3); personShape(c, pose, o.hat === true); c.fill(); c.restore();
  c.globalAlpha = o.a ?? 0.72; c.fillStyle = o.col || COL.shadow;
  personShape(c, pose, o.hat === true); c.fill();
  const m = c.getTransform();
  const head = m.transformPoint(new DOMPoint(0, -192));
  c.restore();
  if (o.rings !== false) {
    const p = c.getTransform().inverse().transformPoint(new DOMPoint(head.x, head.y));
    speechRings(c, p.x + (o.ringDx ?? 14), p.y - 8, o.r0 ?? 16, o.rn ?? 3, t, o.ringCol || COL.ivory, o.ringA ?? 0.55, o.ringDir ?? 1);
  }
  return head;
}
function speechBubble(c, x, y, w, h, tailX, tailY, t, a = 1, o = {}) {
  c.save(); c.globalAlpha = a;
  c.fillStyle = COL.ivory; c.strokeStyle = COL.ink; c.lineWidth = 3;
  rr(c, x - w / 2, y - h / 2, w, h, 12); c.fill(); c.stroke();
  c.beginPath(); c.moveTo(x + (o.tailDx ?? -w * 0.24), y + h / 2 - 2); c.lineTo(tailX, tailY); c.lineTo(x + (o.tailDx ?? -w * 0.24) + 22, y + h / 2 - 2); c.closePath();
  c.fillStyle = COL.ivory; c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 3; c.stroke();
  c.strokeStyle = COL.sepia; c.lineWidth = 3.2; c.lineCap = 'round';
  const rows = o.rows ?? 3;
  for (let i = 0; i < rows; i++) {
    const yy = y - (rows - 1) * 9 + i * 18;
    const len = w * (0.46 + 0.28 * hash(i + 3));
    c.beginPath(); c.moveTo(x - len / 2, yy);
    c.bezierCurveTo(x - len * 0.15, yy - 5, x + len * 0.15, yy + 5, x + len / 2, yy); c.stroke();
  }
  c.restore();
}
function clockFace(c, cx, cy, r, t, label = '0.5 S') {
  c.save();
  c.fillStyle = 'rgba(43,31,23,0.18)'; circ(c, cx + 4, cy + 6, r); c.fill();
  c.fillStyle = brassGrad(c, cx - r, cy - r, cx + r, cy + r); circ(c, cx, cy, r); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3.4; circ(c, cx, cy, r); c.stroke();
  c.fillStyle = COL.ivory; circ(c, cx, cy, r * 0.82); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 2.2; circ(c, cx, cy, r * 0.82); c.stroke();
  for (let i = 0; i < 12; i++) {
    const a = i * TAU / 12, long = i % 3 === 0;
    c.strokeStyle = COL.ink; c.lineWidth = long ? 3 : 1.6;
    c.beginPath(); c.moveTo(cx + Math.cos(a) * r * (long ? 0.58 : 0.66), cy + Math.sin(a) * r * (long ? 0.58 : 0.66));
    c.lineTo(cx + Math.cos(a) * r * 0.76, cy + Math.sin(a) * r * 0.76); c.stroke();
  }
  const a1 = -Math.PI / 2 + t * 0.9, a2 = a1 + Math.PI * 0.86;
  c.strokeStyle = COL.ink; c.lineWidth = 4; c.lineCap = 'round';
  c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(a1) * r * 0.44, cy + Math.sin(a1) * r * 0.44); c.stroke();
  c.strokeStyle = COL.terra; c.lineWidth = 3;
  c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(a2) * r * 0.62, cy + Math.sin(a2) * r * 0.62); c.stroke();
  c.fillStyle = COL.ink; circ(c, cx, cy, 4); c.fill();
  txt(c, label, cx, cy + r + 22, { size: 17, fam: F.mono, weight: 700, col: COL.sepia, ls: 1.6 });
  c.restore();
}
function streetLamp(c, x, baseY, h, t) {
  c.save();
  c.fillStyle = 'rgba(43,31,23,0.18)'; c.beginPath(); c.ellipse(x + 8, baseY + 4, 40, 8, 0, 0, TAU); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 9; c.lineCap = 'round';
  c.beginPath(); c.moveTo(x, baseY); c.lineTo(x, baseY - h); c.stroke();
  c.strokeStyle = COL.iron; c.lineWidth = 5;
  c.beginPath(); c.moveTo(x, baseY); c.lineTo(x, baseY - h); c.stroke();
  c.beginPath(); c.moveTo(x, baseY - h); c.quadraticCurveTo(x + 2, baseY - h - 34, x + 52, baseY - h - 38); c.stroke();
  const gx = x + 52, gy = baseY - h - 30;
  const pulse = 0.84 + 0.16 * Math.sin(t * 2.7) + 0.05 * Math.sin(t * 7.3);
  const gl = c.createRadialGradient(gx, gy, 4, gx, gy, 110);
  gl.addColorStop(0, `rgba(247,233,201,${0.9 * pulse})`); gl.addColorStop(0.28, `rgba(217,130,43,${0.3 * pulse})`); gl.addColorStop(1, 'rgba(217,130,43,0)');
  c.fillStyle = gl; circ(c, gx, gy, 110); c.fill();
  c.fillStyle = COL.cream; poly(c, [gx - 22, gy - 20, gx + 22, gy - 20, gx + 16, gy + 24, gx - 16, gy + 24]); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.stroke();
  c.strokeStyle = 'rgba(30,24,19,0.35)'; c.lineWidth = 2;
  c.beginPath(); c.moveTo(gx - 14, gy - 20); c.lineTo(gx - 10, gy + 24); c.stroke();
  c.beginPath(); c.moveTo(gx + 14, gy - 20); c.lineTo(gx + 10, gy + 24); c.stroke();
  c.fillStyle = COL.ink; poly(c, [gx - 26, gy - 20, gx + 26, gy - 20, gx + 18, gy - 28, gx - 18, gy - 28]); c.fill();
  c.restore();
}
function tree(c, x, baseY, s, t) {
  c.save(); c.translate(x, baseY); c.scale(s, s);
  c.fillStyle = 'rgba(43,31,23,0.16)'; c.beginPath(); c.ellipse(8, 4, 80, 12, 0, 0, TAU); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 16; c.lineCap = 'round';
  c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-8, -150, 6, -300); c.stroke();
  c.strokeStyle = COL.wood; c.lineWidth = 10;
  c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-8, -150, 6, -300); c.stroke();
  c.strokeStyle = COL.ink; c.lineWidth = 7;
  [[-4, -180, -90, -250], [4, -210, 86, -286], [2, -260, -60, -330], [4, -280, 54, -350]].forEach(([x0, y0, x1, y1]) => {
    c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo((x0 + x1) / 2 - 12, (y0 + y1) / 2, x1, y1); c.stroke();
  });
  c.strokeStyle = COL.wood; c.lineWidth = 4;
  [[-4, -180, -90, -250], [4, -210, 86, -286], [2, -260, -60, -330], [4, -280, 54, -350]].forEach(([x0, y0, x1, y1]) => {
    c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo((x0 + x1) / 2 - 12, (y0 + y1) / 2, x1, y1); c.stroke();
  });
  const r = rng(41);
  for (let i = 0; i < 26; i++) {
    const a = r() * TAU, rad = 20 + r() * 100;
    const cx = 6 + Math.cos(a) * rad + Math.sin(t * 1.5 + i * 0.83) * 5;
    const cy = -330 + Math.sin(a) * rad * 0.58 + Math.cos(t * 1.24 + i * 0.61) * 3.5;
    c.fillStyle = i % 3 === 0 ? COL.oliveD : (i % 3 === 1 ? COL.olive : '#8A8456');
    c.globalAlpha = 0.82 + r() * 0.18;
    circ(c, cx, cy, 28 + r() * 34); c.fill();
    c.strokeStyle = 'rgba(30,24,19,0.28)'; c.lineWidth = 1.4; c.stroke();
  }
  c.globalAlpha = 1;
  c.restore();
}
function bench(c, x, baseY, s) {
  c.save(); c.translate(x, baseY); c.scale(s, s);
  c.strokeStyle = COL.ink; c.lineWidth = 7; c.lineCap = 'round';
  [[-100, 0], [100, 0]].forEach(([px]) => { c.beginPath(); c.moveTo(px, 0); c.lineTo(px, -90); c.stroke(); });
  c.strokeStyle = COL.wood; c.lineWidth = 4;
  [[-100, 0], [100, 0]].forEach(([px]) => { c.beginPath(); c.moveTo(px, 0); c.lineTo(px, -90); c.stroke(); });
  c.fillStyle = COL.wood; rr(c, -128, -104, 256, 20, 3); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 3; c.stroke();
  c.fillStyle = COL.wood; rr(c, -128, -148, 256, 16, 3); c.fill(); c.stroke();
  c.strokeStyle = COL.ink; c.lineWidth = 6;
  c.beginPath(); c.moveTo(-112, -92); c.lineTo(-112, -150); c.stroke();
  c.beginPath(); c.moveTo(112, -92); c.lineTo(112, -150); c.stroke();
  c.restore();
}
function armchair(c, x, baseY, s, t) {
  c.save(); c.translate(x, baseY); c.scale(s, s);
  c.fillStyle = 'rgba(43,31,23,0.20)'; c.beginPath(); c.ellipse(6, 4, 92, 12, 0, 0, TAU); c.fill();
  c.fillStyle = COL.woodD; rr(c, -78, -46, 156, 46, 8); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 3.4; c.stroke();
  c.fillStyle = COL.wood; rr(c, -82, -180, 164, 140, 14); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 4; c.stroke();
  c.fillStyle = COL.wood; rr(c, -96, -120, 34, 96, 10); c.fill(); c.stroke();
  c.fillStyle = COL.wood; rr(c, 62, -120, 34, 96, 10); c.fill(); c.stroke();
  c.strokeStyle = 'rgba(250,247,240,0.18)'; c.lineWidth = 2;
  for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(-60 + i * 34, -168); c.lineTo(-60 + i * 34, -52); c.stroke(); }
  c.restore();
}
function portraitFrame(c, x, y, w, h, label) {
  c.save();
  c.fillStyle = 'rgba(43,31,23,0.22)'; rr(c, x - w / 2 + 4, y - h / 2 + 6, w, h, 3); c.fill();
  c.fillStyle = brassGrad(c, x - w / 2, y - h / 2, x + w / 2, y + h / 2); rr(c, x - w / 2, y - h / 2, w, h, 3); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3; rr(c, x - w / 2, y - h / 2, w, h, 3); c.stroke();
  c.fillStyle = COL.vellum; c.fillRect(x - w / 2 + 10, y - h / 2 + 10, w - 20, h - 20);
  c.strokeStyle = COL.ink; c.lineWidth = 2; c.strokeRect(x - w / 2 + 10, y - h / 2 + 10, w - 20, h - 20);
  c.fillStyle = COL.shadow2; c.beginPath(); c.ellipse(x, y - 14, w * 0.19, h * 0.16, 0, 0, TAU); c.fill();
  c.beginPath(); c.moveTo(x - w * 0.26, y + h / 2 - 18); c.quadraticCurveTo(x, y - h * 0.02, x + w * 0.26, y + h / 2 - 18); c.closePath(); c.fill();
  txt(c, label, x, y + h / 2 - 18, { size: 15, fam: F.mono, weight: 700, col: COL.ivory, ls: 1.4 });
  c.restore();
}
function cityline(c, y, t, a = 1) {
  c.save(); c.globalAlpha = a;
  const r = rng(73);
  let x = 80;
  while (x < 1000) {
    const w = 40 + r() * 80, h = 70 + r() * 210;
    c.fillStyle = COL.shadow2; c.fillRect(x, y - h, w, h);
    c.strokeStyle = 'rgba(30,24,19,0.5)'; c.lineWidth = 2; c.strokeRect(x, y - h, w, h);
    for (let wy = y - h + 16; wy < y - 14; wy += 24) {
      for (let wx = x + 9; wx < x + w - 10; wx += 18) {
        if (r() > 0.42) {
          const fl = 0.5 + 0.5 * Math.sin(t * (1.1 + (wx % 7) * 0.22) + wx * 0.07 + wy * 0.13);
          c.fillStyle = r() > 0.7 ? `rgba(247,233,201,${0.44 + 0.52 * fl})` : `rgba(217,130,43,${0.38 + 0.5 * fl})`;
          c.fillRect(wx, wy, 8, 11);
        }
      }
    }
    x += w + 8;
  }
  c.restore();
}
function floorPlanks(c, x0, x1, y0, y1, step = 64, a = 0.06) {
  c.save();
  for (let y = y0; y < y1; y += step) {
    c.strokeStyle = `rgba(250,247,240,${a})`; c.lineWidth = 2;
    c.beginPath(); c.moveTo(x0, y); c.lineTo(x1, y); c.stroke();
  }
  c.strokeStyle = `rgba(20,16,12,${a * 1.1})`; c.lineWidth = 2;
  for (let x = x0 + 90; x < x1; x += 150) {
    c.beginPath(); c.moveTo(x, y0); c.lineTo(x - 28, y1); c.stroke();
  }
  c.restore();
}
function moon(c, x, y, r) {  c.save();
  const gl = c.createRadialGradient(x, y, r * 0.5, x, y, r * 3.2);
  gl.addColorStop(0, 'rgba(247,233,201,0.34)'); gl.addColorStop(1, 'rgba(247,233,201,0)');
  c.fillStyle = gl; circ(c, x, y, r * 3.2); c.fill();
  c.fillStyle = COL.cream; circ(c, x, y, r); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 2.6; circ(c, x, y, r); c.stroke();
  c.fillStyle = 'rgba(92,82,72,0.16)';
  circ(c, x - r * 0.3, y - r * 0.18, r * 0.18); c.fill();
  circ(c, x + r * 0.24, y + r * 0.26, r * 0.13); c.fill();
  circ(c, x + r * 0.1, y - r * 0.42, r * 0.09); c.fill();
  c.restore();
}
function hatching(c, x, y, w, h, step, a = 0.10) {
  c.save(); c.strokeStyle = `rgba(30,24,19,${a})`; c.lineWidth = 1.4;
  for (let i = -h; i < w; i += step) {
    c.beginPath(); c.moveTo(x + i, y); c.lineTo(x + i + h, y + h); c.stroke();
  }
  c.restore();
}

// ── the living plate: one camera that never stops, and a vocabulary of small motions ─────────────
const sw = (t, f, ph = 0, a = 1) => Math.sin(t * f + ph) * a;
function camera(c, o, lt, t, seed = 0) {
  const cx = o.x + o.w / 2, cy = 980;
  const enter = 1.055 - 0.055 * eo(clamp(lt / 0.42));
  const push = 1 + 0.075 * clamp(lt / 5.2);
  const k = enter * push * (1 + 0.005 * Math.sin(t * 2.1 + seed));
  const dx = Math.sin(t * 0.67 + seed * 1.7) * 10 + Math.sin(t * 1.53 + seed) * 4.5;
  const dy = Math.cos(t * 0.55 + seed) * 9 + Math.sin(t * 1.27 + seed * 2.3) * 4;
  const rot = Math.sin(t * 0.43 + seed * 0.9) * 0.0065;
  c.translate(cx + dx, cy + dy); c.rotate(rot); c.scale(k, k); c.translate(-cx, -cy);
}
function glow(c, x, y, r, col, a) {
  const g = c.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, rgba(col, a)); g.addColorStop(0.4, rgba(col, a * 0.34)); g.addColorStop(1, rgba(col, 0));
  c.fillStyle = g; circ(c, x, y, r); c.fill();
}
function dust(c, t, o = {}) {
  const { x0 = 110, x1 = 970, y0 = 300, y1 = 1160, n = 26, seed = 5, a = 0.42, drift = 12 } = o;
  const r = rng(seed);
  c.save();
  for (let i = 0; i < n; i++) {
    const bx = x0 + r() * (x1 - x0), by = y0 + r() * (y1 - y0);
    const sp = 0.5 + r() * 1.7, ph = r() * TAU, sz = 0.9 + r() * 2.1, al = 0.16 + r() * 0.5, big = r() > 0.7 ? 1.5 : 1;
    const px = bx + Math.sin(t * 0.62 * sp + ph) * drift + Math.sin(t * 0.21 + ph) * 6;
    const py = y0 + ((by - y0 - t * (5 + sp * 10) + (y1 - y0) * 1000) % (y1 - y0));
    c.fillStyle = `rgba(247,233,201,${a * al * (0.5 + 0.5 * Math.sin(t * 2.3 + ph))})`;
    circ(c, px, py, sz * big); c.fill();
  }
  c.restore();
}
function stars(c, o, t, n = 80, seed = 67) {  const r = rng(seed);
  for (let i = 0; i < n; i++) {
    const x = o.x + 10 + r() * (o.w - 20), y = o.y + 10 + r() * 540;
    const b = 0.18 + r() * 0.5, ph = r() * TAU, sp = 1.4 + r() * 3.4;
    c.fillStyle = `rgba(247,233,201,${b * (0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * sp + ph)))})`;
    circ(c, x, y, 0.7 + r() * 1.5); c.fill();
  }
}
function glint(c, o, t, ph = 0, a = 0.07) {
  const p = (t * 0.2 + ph) % 1;
  const x = o.x - 240 + p * (o.w + 480);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  const g = c.createLinearGradient(x - 150, o.y, x + 150, o.y + o.h);
  g.addColorStop(0, 'rgba(255,250,235,0)'); g.addColorStop(0.5, `rgba(255,250,235,${a})`); g.addColorStop(1, 'rgba(255,250,235,0)');
  c.fillStyle = g; c.fillRect(o.x, o.y, o.w, o.h); c.restore();
}
function sweep(c, y, h, t, a = 0.06, ph = 0) {
  const x = 40 + ((t * 190 + ph * 900) % 1000);
  const g = c.createLinearGradient(x - 180, y, x + 180, y);
  g.addColorStop(0, 'rgba(255,250,235,0)'); g.addColorStop(0.5, `rgba(255,250,235,${a})`); g.addColorStop(1, 'rgba(255,250,235,0)');
  c.fillStyle = g; c.fillRect(104, y, 872, h);
}
function tickClock(c, cx, cy, r, t, tick = 1) {
  const sec = (Math.floor(t / tick) % 60) / 60;
  const a = -Math.PI / 2 + sec * TAU;
  c.strokeStyle = COL.terra; c.lineWidth = 2.4; c.lineCap = 'round';
  c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(a) * r * 0.7, cy + Math.sin(a) * r * 0.7); c.stroke();
}

// ── S01 · THE WITNESS (cold open — no title card, no spoken title) ─────────────────────────────
function sceneWitness(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 0.7);
  const sky = c.createLinearGradient(0, o.y, 0, 900);
  sky.addColorStop(0, '#F3E3C6'); sky.addColorStop(0.55, '#E4C79E'); sky.addColorStop(1, '#A87F58');
  c.fillStyle = sky; c.fillRect(o.x, o.y, o.w, o.h);
  // clouds sliding behind the sun
  c.save(); c.fillStyle = 'rgba(255,248,232,0.30)';
  [[0.14, 470, 150, 20], [0.42, 512, 210, 26], [0.7, 452, 120, 16]].forEach(([ph, y, w, h], i) => {
    const x = o.x - 200 + ((t * (16 + i * 7) + ph * 1200) % 1300);
    c.beginPath(); c.ellipse(x, y + sw(t, 0.8, i) * 4, w, h, 0, 0, TAU); c.fill();
  });
  c.restore();
  const glowA = 0.2 + 0.07 * sw(t, 1.8);
  glow(c, 740, 560, 236 + sw(t, 1.3) * 10, COL.amber, glowA);
  c.fillStyle = COL.ivory; circ(c, 740, 560, 46 + sw(t, 2.2) * 1.2); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3; circ(c, 740, 560, 46 + sw(t, 2.2) * 1.2); c.stroke();
  cityline(c, 900, t, 0.55);
  const gr = c.createLinearGradient(0, 880, 0, o.y + o.h);
  gr.addColorStop(0, '#8C6A4A'); gr.addColorStop(1, '#4A3A2A');
  c.fillStyle = gr; c.fillRect(o.x, 880, o.w, o.y + o.h - 880);
  c.strokeStyle = COL.ink; c.lineWidth = 3;
  c.beginPath(); c.moveTo(o.x, 880); c.lineTo(o.x + o.w, 880); c.stroke();
  for (let i = 0; i < 16; i++) {
    const yy = 912 + i * 28;
    c.strokeStyle = `rgba(250,247,240,${0.18 - i * 0.014})`; c.lineWidth = 2;
    c.beginPath(); c.moveTo(o.x + 10, yy + sw(t, 1.1, i * 0.7) * 1.2); c.lineTo(o.x + o.w - 10, yy + sw(t, 1.1, i * 0.7 + 1.4) * 1.2); c.stroke();
  }
  // the wall the shadow is thrown on
  c.fillStyle = '#B99A78'; c.fillRect(590, 400, 386, 500);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.strokeRect(590, 400, 386, 500);
  hatching(c, 590, 400, 386, 500, 26, 0.06);
  c.save(); c.beginPath(); c.rect(592, 402, 382, 496); c.clip();
  for (let i = 0; i < 8; i++) {
    c.strokeStyle = 'rgba(92,82,72,0.18)'; c.lineWidth = 1.6;
    c.beginPath(); c.moveTo(590, 450 + i * 58 + sw(t, 0.9, i) * 2); c.lineTo(976, 450 + i * 58 + sw(t, 0.9, i + 2) * 2); c.stroke();
  }
  sweep(c, 400, 500, t, 0.05, 0.35);
  c.restore();
  streetLamp(c, 520, 1030, 340, t);
  // the projection line from the walker to the wall
  c.save(); c.strokeStyle = 'rgba(30,24,19,0.26)'; c.lineWidth = 2; c.setLineDash([6, 11]);
  c.lineDashOffset = -t * 52;
  c.beginPath(); c.moveTo(330, 1048); c.quadraticCurveTo(560, 1062 + sw(t, 1.4) * 3, 792, 1014); c.stroke(); c.setLineDash([]); c.restore();
  // the walker and the shadow that has been listening
  const wx = 318 + clamp(lt / 3.0) * 44;
  c.save();
  c.translate(wx, 1048 - Math.abs(Math.sin(t * 3.6)) * 5);
  c.rotate(sw(t, 2.4) * 0.016);
  person(c, 0, 0, 1.15, { pose: 'walk', rim: true });
  c.restore();
  c.save(); rr(c, 590, 400, 386, 500, 0); c.clip();
  wallShadow(c, 792 + sw(t, 1.2) * 3, 1012, 1.42 + sw(t, 1.7) * 0.015, -0.05 + sw(t, 1.5) * 0.022, 'stand', t, { hat: true, ringDx: 30, r0: 34, rn: 4, ringA: 0.9, ringCol: 'rgba(30,24,19,0.55)' });
  c.restore();
  // a discarded playbill, fluttering in the gutter wind
  c.save(); c.translate(202, 1024 + sw(t, 2.1) * 3); c.rotate(-0.12 + sw(t, 2.7) * 0.05);
  c.fillStyle = COL.ivory; rr(c, -36, -20, 72, 40, 2); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 2; rr(c, -36, -20, 72, 40, 2); c.stroke();
  txt(c, 'LISTEN', 0, -3, { size: 12, fam: F.mono, weight: 700, col: COL.terra, ls: 1.1 });
  txt(c, 'No. 10', 0, 12, { size: 10, fam: F.mono, weight: 500, col: COL.sepia, ls: 1 });
  c.restore();
  dust(c, t, { n: 30, seed: 11, a: 0.5, y0: 340, y1: 1140 });
  glint(c, o, t, 0.25, 0.06);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE I · THE WITNESS');
  fig(c, 'FIG. 01 — SHADOW · RECORDING', 1372, { dark: true });
  tag(c, 'TAKING NOTES', COL.ivory, clamp((t - wd(0, 4).s) / 0.25), TAG_Y);
  subs(c, 0, t);
  badge(c, t);
  c.restore();
}

// ── S02 · THE ECHO ──────────────────────────────────────────────────────────────────────────────
function sceneEcho(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 1.9);
  const wall = c.createLinearGradient(0, o.y, 0, 1000);
  wall.addColorStop(0, '#C8A982'); wall.addColorStop(1, '#8C6A4A');
  c.fillStyle = wall; c.fillRect(o.x, o.y, o.w, o.h);
  for (let i = 0; i < 18; i++) {
    c.strokeStyle = `rgba(92,82,72,${0.10 + (i % 3) * 0.03})`; c.lineWidth = 2;
    c.beginPath(); c.moveTo(o.x + 22 + i * 50 + sw(t, 0.7, i) * 1.5, o.y); c.lineTo(o.x + 22 + i * 50 + sw(t, 0.7, i + 1) * 1.5, 960); c.stroke();
  }
  sweep(c, 300, 660, t, 0.045, 0.1);
  c.fillStyle = COL.woodD; c.fillRect(o.x, 960, o.w, o.y + o.h - 960);
  floorPlanks(c, o.x, o.x + o.w, 990, o.y + o.h, 70, 0.05);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.beginPath(); c.moveTo(o.x, 960); c.lineTo(o.x + o.w, 960); c.stroke();
  // window on the left wall
  c.fillStyle = COL.night; c.fillRect(150, 390, 210, 300);
  c.strokeStyle = COL.ink; c.lineWidth = 5; c.strokeRect(150, 390, 210, 300);
  c.strokeStyle = COL.wood; c.lineWidth = 5;
  c.beginPath(); c.moveTo(255, 390); c.lineTo(255, 690); c.stroke();
  c.beginPath(); c.moveTo(150, 540); c.lineTo(360, 540); c.stroke();
  moon(c, 318, 462 + sw(t, 1.1) * 1.5, 30);
  c.fillStyle = 'rgba(247,233,201,0.85)';
  for (let i = 0; i < 6; i++) {
    const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * (1.4 + i * 0.3) + i * 1.7));
    c.globalAlpha = tw; circ(c, 176 + (i * 37) % 150, 414 + (i * 53) % 100, 1.7); c.fill();
  }
  c.globalAlpha = 1;
  // the shadow on the wall above the bed
  const head = wallShadow(c, 700 + sw(t, 1.3) * 3, 850, 1.28 + sw(t, 1.8) * 0.014, 0.02 + sw(t, 1.1) * 0.024, 'sit', t, { hat: true, a: 0.60, ringDx: 28, r0: 30, rn: 4, ringA: 0.9, ringCol: 'rgba(30,24,19,0.55)' });
  // bed, breathing under the sleeper
  c.save(); c.translate(0, sw(t, 1.2) * 1.6);
  c.fillStyle = COL.wood; rr(c, 560, 840, 390, 44, 6); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3.4; rr(c, 560, 840, 390, 44, 6); c.stroke();
  c.fillStyle = COL.ivory; rr(c, 576, 800, 358, 52, 8); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3; rr(c, 576, 800, 358, 52, 8); c.stroke();
  c.fillStyle = COL.cream; rr(c, 582, 758, 92, 52, 6); c.fill(); c.stroke();
  c.strokeStyle = COL.ink; c.lineWidth = 5;
  c.beginPath(); c.moveTo(560, 884); c.lineTo(560, 960); c.stroke();
  c.beginPath(); c.moveTo(950, 884); c.lineTo(950, 960); c.stroke();
  c.restore();
  // the sitter
  c.save(); c.translate(760, 946 - Math.abs(Math.sin(t * 1.8)) * 2);
  person(c, 0, 0, 1.02, { pose: 'sit', rim: true });
  c.restore();
  // the repeating bubble, clear of the mouth
  c.save(); c.translate(0, sw(t, 1.7, 1) * 4);
  speechBubble(c, 590, 500, 150, 92, 700, 526, t, 0.95, { tailDx: 20, rows: 3 });
  c.restore();
  // the half-second clock
  clockFace(c, 890, 700 + sw(t, 1.4) * 2, 50, t, '0.5 S');
  // side table and lamp, left of the bed
  c.fillStyle = COL.wood; rr(c, 398, 850, 120, 110, 4); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 3; c.stroke();
  c.fillStyle = COL.cream; poly(c, [418, 850, 498, 850, 484, 812, 432, 812]); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2.6; c.stroke();
  c.strokeStyle = COL.ink; c.lineWidth = 4; c.beginPath(); c.moveTo(458, 850); c.lineTo(458, 884); c.stroke();
  glow(c, 458, 830, 92 + sw(t, 3.1) * 6, COL.cream, 0.16 + 0.1 * Math.abs(sw(t, 2.7)));
  dust(c, t, { n: 22, seed: 23, a: 0.4, y0: 360, y1: 1140, drift: 9 });
  glint(c, o, t, 0.62, 0.05);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE II · THE ECHO');
  fig(c, 'FIG. 02 — PLAYBACK · 0.5 S DELAY', 1372, { dark: true });
  tag(c, 'HALF A SECOND LATE', COL.ivory, clamp((t - wd(1, 10).s) / 0.25), TAG_Y);
  subs(c, 1, t);
  badge(c, t);
  c.restore();
}

// ── S03 · THE NOON PARLEY ───────────────────────────────────────────────────────────────────────
function sceneParley(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 3.1);
  const sky = c.createLinearGradient(0, o.y, 0, 760);
  sky.addColorStop(0, '#F7E9C9'); sky.addColorStop(1, '#E8D5B4');
  c.fillStyle = sky; c.fillRect(o.x, o.y, o.w, o.h);
  glow(c, 780, 420, 190 + sw(t, 1.6) * 12, COL.amber, 0.2 + 0.06 * sw(t, 2.0));
  c.fillStyle = COL.ivory; circ(c, 780, 420, 42 + sw(t, 2.4) * 1.4); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3; circ(c, 780, 420, 42 + sw(t, 2.4) * 1.4); c.stroke();
  // distant tree line, breathing in the heat
  const r = rng(19);
  for (let i = 0; i < 14; i++) {
    const x = 120 + i * 62 + r() * 18 + sw(t, 0.9, i * 0.8) * 3, h = 60 + r() * 60;
    c.fillStyle = i % 2 ? COL.oliveD : COL.olive;
    c.globalAlpha = 0.55; circ(c, x, 742 - h * 0.2, h * 0.42); c.fill();
    c.globalAlpha = 1;
  }
  const grass = c.createLinearGradient(0, 740, 0, o.y + o.h);
  grass.addColorStop(0, '#8A8456'); grass.addColorStop(0.6, '#6E6A45'); grass.addColorStop(1, '#4A4730');
  c.fillStyle = grass; c.fillRect(o.x, 740, o.w, o.y + o.h - 740);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.beginPath(); c.moveTo(o.x, 740); c.lineTo(o.x + o.w, 740); c.stroke();
  // path with a travelling noon glare
  c.fillStyle = '#C9B18C'; c.beginPath();
  c.moveTo(420, 740); c.bezierCurveTo(470, 840, 380, 960, 300, o.y + o.h);
  c.lineTo(760, o.y + o.h); c.bezierCurveTo(700, 960, 640, 840, 620, 740); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(30,24,19,0.28)'; c.lineWidth = 2; c.stroke();
  c.save(); c.clip();
  c.globalAlpha = 0.35; glow(c, 520 + sw(t, 0.9) * 240, 900 + sw(t, 1.3) * 60, 150, COL.ivory, 0.5); c.restore();
  // a low sunlit park wall, and the bench in front of it
  const stone = c.createLinearGradient(0, 740, 0, 980);
  stone.addColorStop(0, '#D8C09A'); stone.addColorStop(0.55, '#C9B18C'); stone.addColorStop(1, '#A58A68');
  c.fillStyle = stone; rr(c, 120, 700, 840, 280, 2); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3.4; rr(c, 120, 700, 840, 280, 2); c.stroke();
  c.fillStyle = '#B79A74'; rr(c, 112, 686, 856, 20, 2); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3.4; rr(c, 112, 686, 856, 20, 2); c.stroke();
  c.strokeStyle = 'rgba(92,82,72,0.32)'; c.lineWidth = 2;
  for (let r2 = 0; r2 < 3; r2++) {
    const yy = 758 + r2 * 62;
    c.beginPath(); c.moveTo(124, yy); c.lineTo(956, yy); c.stroke();
    for (let i = 0; i < 8; i++) {
      const x = 150 + i * 108 + (r2 % 2) * 54;
      c.beginPath(); c.moveTo(x, yy); c.lineTo(x, yy + 62); c.stroke();
    }
  }
  c.fillStyle = 'rgba(250,247,240,0.13)'; c.fillRect(124, 704, 832, 54);
  c.save(); rr(c, 120, 700, 840, 280, 2); c.clip();
  sweep(c, 700, 280, t, 0.08, 0.55);
  c.restore();
  // their shadows on the wall, leaning together and shifting as they talk
  wallShadow(c, 390 + sw(t, 1.2, 0.4) * 4, 950, 0.78, 0.12 + sw(t, 1.1, 0.4) * 0.02, 'sit', t, { a: 0.62, hat: true, mouthCol: COL.cream, ringDx: 18, r0: 22, rn: 3, ringA: 0.8, ringCol: 'rgba(30,24,19,0.55)', ringDir: 1 });
  wallShadow(c, 560 + sw(t, 1.5, 1.9) * 4, 948, 0.78 + sw(t, 1.9) * 0.01, 0.0 + sw(t, 1.3, 1.9) * 0.02, 'sit', t, { a: 0.62, hat: true, mouthCol: COL.cream, ringDx: 18, r0: 22, rn: 3, ringA: 0.8, ringCol: 'rgba(30,24,19,0.55)', ringDir: 1 });
  wallShadow(c, 730 + sw(t, 1.35, 3.3) * 4, 950, 0.78, -0.12 + sw(t, 1.2, 3.3) * 0.02, 'sit', t, { a: 0.62, hat: true, mouthCol: COL.cream, ringDx: -18, r0: 22, rn: 3, ringA: 0.8, ringCol: 'rgba(30,24,19,0.55)', ringDir: -1 });
  // three bubbles of park gossip
  c.save(); c.translate(0, sw(t, 1.6, 0) * 4);
  speechBubble(c, 360, 626, 150, 86, 380, 738, t, 0.94, { tailDx: -10, rows: 2 });
  c.restore();
  c.save(); c.translate(sw(t, 1.3, 2) * 3, sw(t, 1.8, 2) * 5);
  speechBubble(c, 560, 570, 166, 94, 560, 728, t, 0.97, { tailDx: 0, rows: 3 });
  c.restore();
  c.save(); c.translate(0, sw(t, 1.5, 4) * 4);
  speechBubble(c, 760, 626, 150, 86, 740, 738, t, 0.94, { tailDx: 10, rows: 2 });
  c.restore();
  c.save(); c.translate(158, 1010); c.rotate(sw(t, 0.8) * 0.012); tree(c, 0, 0, 1.16, t); c.restore();
  bench(c, 560, 1040, 1.06);
  // the people, sitting with their backs to the wall
  const heads = [[380, 1002, 0.3], [560, 1000, 1.7], [740, 1002, 2.8]];
  heads.forEach(([x, y, ph]) => {
    c.save(); c.translate(0, sw(t, 1.5, ph) * 2.2); c.rotate(sw(t, 0.9, ph) * 0.006);
    person(c, x, y, 0.95, { pose: 'sit', rim: true, hat: false, flip: x === 560 || x === 740 });
    c.restore();
  });
  // noon sparkles, orbiting the sun
  for (let i = 0; i < 12; i++) {
    const a = i * 1.7 + t * 0.35;
    const tw = 0.35 + 0.65 * Math.abs(Math.sin(t * 2.2 + i * 0.9));
    c.fillStyle = `rgba(250,247,240,${0.75 * tw})`;
    circ(c, 500 + Math.cos(a) * 220, 640 + Math.sin(a) * 60, 1.6 + tw * 1.2); c.fill();
  }
  dust(c, t, { n: 18, seed: 31, a: 0.45, y0: 330, y1: 1120, drift: 16 });
  glint(c, o, t, 0.85, 0.06);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE III · THE NOON PARLEY');
  fig(c, 'FIG. 03 — SHADOWS · IN CONFERENCE', 1372, { dark: true });
  tag(c, 'LEANING TOGETHER', COL.ivory, clamp((t - wd(2, 9).s) / 0.25), TAG_Y);
  subs(c, 2, t);
  badge(c, t);
  c.restore();
}

// ── S04 · THE HEIRLOOM ──────────────────────────────────────────────────────────────────────────
function sceneHeirloom(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 4.3);
  const wall = c.createLinearGradient(0, o.y, 0, 1000);
  wall.addColorStop(0, '#3A2C22'); wall.addColorStop(0.7, '#241C16'); wall.addColorStop(1, '#17120E');
  c.fillStyle = wall; c.fillRect(o.x, o.y, o.w, o.h);
  hatching(c, o.x, o.y, o.w, 700, 40, 0.05);
  // a wash of lamp light on the wall, breathing so the shadow keeps changing
  const washA = 0.26 + 0.07 * Math.abs(sw(t, 2.4)) + 0.03 * sw(t, 6.1);
  const wash = c.createRadialGradient(600, 820, 30, 600, 820, 360 + sw(t, 1.5) * 14);
  wash.addColorStop(0, `rgba(232,199,140,${washA})`);
  wash.addColorStop(0.55, `rgba(217,130,43,${washA * 0.44})`);
  wash.addColorStop(1, 'rgba(217,130,43,0)');
  c.fillStyle = wash; c.fillRect(o.x, o.y, o.w, o.h);
  const floor = c.createLinearGradient(0, 1000, 0, o.y + o.h);
  floor.addColorStop(0, '#3A2518'); floor.addColorStop(1, '#1C1712');
  c.fillStyle = floor; c.fillRect(o.x, 1000, o.w, o.y + o.h - 1000);
  floorPlanks(c, o.x, o.x + o.w, 1030, o.y + o.h, 74, 0.045);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.beginPath(); c.moveTo(o.x, 1000); c.lineTo(o.x + o.w, 1000); c.stroke();
  // rug
  c.fillStyle = '#5C3A2A'; c.beginPath(); c.ellipse(540, 1090, 300, 52, 0, 0, TAU); c.fill();
  c.strokeStyle = COL.brassD; c.lineWidth = 3; c.stroke();
  c.strokeStyle = `rgba(200,157,66,${0.25 + 0.18 * Math.abs(sw(t, 1.9))})`; c.lineWidth = 1.6; c.beginPath(); c.ellipse(540, 1090, 270, 42, 0, 0, TAU); c.stroke();
  // portrait, breathing on its nail
  c.save(); c.translate(806, 498 + sw(t, 1.6) * 2); c.rotate(sw(t, 1.1) * 0.01);
  portraitFrame(c, 0, 0, 190, 244, 'ABSENT');
  c.restore();
  // the shadow that stayed
  const head = wallShadow(c, 548 + sw(t, 1.25) * 4, 1006, 1.50 + sw(t, 1.7) * 0.012, 0 + sw(t, 1.45) * 0.018, 'sit', t, { a: 0.86, col: '#120D09', ringDx: 34, r0: 34, rn: 4, ringA: 0.75, ringCol: 'rgba(247,233,201,0.8)' });
  // armchair, breathing as if someone just left it
  c.save(); c.translate(0, sw(t, 1.4) * 1.8);
  armchair(c, 536, 1014, 1.24, t);
  c.restore();
  // side table and lamp
  c.fillStyle = COL.wood; rr(c, 800, 880, 150, 120, 4); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 3; c.stroke();
  c.fillStyle = COL.cream; poly(c, [824, 880, 926, 880, 910, 838, 840, 838]); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2.6; c.stroke();
  c.strokeStyle = COL.ink; c.lineWidth = 4; c.beginPath(); c.moveTo(875, 880); c.lineTo(875, 918); c.stroke();
  const gl = c.createRadialGradient(875, 862, 6, 875, 862, 120 + sw(t, 3.3) * 8);
  gl.addColorStop(0, `rgba(247,233,201,${0.3 + 0.14 * Math.abs(sw(t, 2.6))})`); gl.addColorStop(1, 'rgba(247,233,201,0)');
  c.fillStyle = gl; circ(c, 875, 862, 130); c.fill();
  // cane, leaning and slipping
  c.save(); c.translate(286, 1082); c.rotate(sw(t, 1.3) * 0.02);
  c.strokeStyle = COL.ink; c.lineWidth = 7; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-14, 0); c.quadraticCurveTo(-28, -72, 14, -78); c.stroke();
  c.strokeStyle = COL.brass; c.lineWidth = 3; c.stroke();
  c.fillStyle = COL.brass; circ(c, 14, -78, 8); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2; c.stroke();
  c.restore();
  // dust in the lamp beam
  dust(c, t, { n: 34, seed: 47, a: 0.55, y0: 340, y1: 1130, drift: 14 });
  glint(c, o, t, 0.47, 0.05);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE IV · THE HEIRLOOM');
  fig(c, 'FIG. 04 — SHADOW · OUTLIVES THE CASTER', 1372, { dark: true });
  tag(c, 'STILL TALKING', COL.ivory, clamp((t - wd(3, 6).s) / 0.25), TAG_Y);
  subs(c, 3, t);
  badge(c, t);
  c.restore();
}

// ── S05 · THE DEAFENING DARK ────────────────────────────────────────────────────────────────────
function sceneNight(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 5.6);
  const sky = c.createLinearGradient(0, o.y, 0, 1000);
  sky.addColorStop(0, '#14100C'); sky.addColorStop(0.55, '#241C16'); sky.addColorStop(1, '#3A2C22');
  c.fillStyle = sky; c.fillRect(o.x, o.y, o.w, o.h);
  stars(c, o, t, 90, 67);
  // a thin cloud crossing the moon
  c.save(); c.fillStyle = 'rgba(247,233,201,0.055)';
  const cx0 = o.x - 300 + ((t * 26) % 1400);
  c.beginPath(); c.ellipse(cx0, 452, 190, 26, 0, 0, TAU); c.fill();
  c.beginPath(); c.ellipse(cx0 + 120, 470, 130, 16, 0, 0, TAU); c.fill();
  c.restore();
  glow(c, 806, 404, 150 + sw(t, 1.4) * 10, COL.cream, 0.2 + 0.05 * sw(t, 1.9));
  moon(c, 806, 404 + sw(t, 1.1) * 2, 54);
  c.save(); c.translate(sw(t, 0.5) * 5, 0); cityline(c, 982, t, 0.95); c.restore();
  // our rooftop, in the foreground, washed by the moon
  c.fillStyle = '#1C1712'; c.fillRect(o.x, 1040, o.w, o.y + o.h - 1040);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.beginPath(); c.moveTo(o.x, 1040); c.lineTo(o.x + o.w, 1040); c.stroke();
  c.fillStyle = '#2B1F17'; c.fillRect(o.x, 1040, o.w, 18);
  const roofWash = c.createRadialGradient(800, 1110, 30, 800, 1110, 460 + sw(t, 1.3) * 18);
  roofWash.addColorStop(0, `rgba(247,233,201,${0.09 + 0.035 * Math.abs(sw(t, 1.7))})`); roofWash.addColorStop(1, 'rgba(247,233,201,0)');
  c.fillStyle = roofWash; c.fillRect(o.x, 1040, o.w, o.y + o.h - 1040);
  // a chorus on the distant rooftops, all of them shifting
  const far = [[460, 986, 0.50, 0.02], [560, 984, 0.54, -0.02], [700, 990, 0.60, 0.02], [840, 984, 0.52, -0.02], [940, 986, 0.50, -0.02]];
  far.forEach(([x, y, s, rot], i) => {
    c.save(); c.translate(0, sw(t, 1.6, i * 1.3) * 2);
    wallShadow(c, x + sw(t, 1.2, i) * 3, y, s + sw(t, 1.8, i) * 0.008, rot + sw(t, 1.35, i * 1.7) * 0.02, i === 2 ? 'stand' : 'turn', t, { a: 0.78, col: '#0F0B08', edge: 'rgba(247,233,201,0.18)', hat: true, mouthCol: COL.cream, rings: false });
    speechRings(c, x + (rot < 0 ? 22 : -22), y - 176 * s, 13, 2, t + i * 0.2, 'rgba(247,233,201,0.55)', 0.55, rot < 0 ? 1 : -1);
    c.restore();
  });
  // a nearer ring of shadows on our own roof
  const near = [[500, 1082, 0.74, 0.03], [680, 1092, 0.80, -0.03], [860, 1084, 0.70, 0.02]];
  near.forEach(([x, y, s, rot], i) => {
    c.save(); c.translate(0, sw(t, 1.5, i * 2.1 + 0.7) * 2.5);
    wallShadow(c, x + sw(t, 1.1, i * 2.2) * 3, y, s + sw(t, 1.7, i * 2.2) * 0.01, rot + sw(t, 1.3, i * 2.9) * 0.022, i % 2 ? 'stand' : 'turn', t, { a: 0.82, col: '#0F0B08', edge: 'rgba(247,233,201,0.14)', hat: true, mouthCol: COL.cream, rings: false });
    if (i !== 2) speechRings(c, x + 26, y - 176 * s, 18, 3, t + i * 0.25, 'rgba(247,233,201,0.72)', 0.62, 1);
    c.restore();
  });
  // one person, listening to all of them
  c.save(); c.translate(250, 1118 - Math.abs(sw(t, 1.2)) * 2); c.rotate(sw(t, 0.9) * 0.012);
  person(c, 0, 0, 1.06, { pose: 'stand', rim: true, hat: false });
  c.restore();
  // the night itself, humming
  speechRings(c, 470, 760, 74, 3, t + 0.4, 'rgba(247,233,201,0.16)', 0.5, 1);
  speechRings(c, 760, 720, 62, 3, t + 0.9, 'rgba(247,233,201,0.14)', 0.45, -1);
  speechRings(c, 330, 700, 54, 2, t + 1.3, 'rgba(247,233,201,0.11)', 0.4, 1);
  speechRings(c, 640, 650, 46, 2, t + 0.7, 'rgba(247,233,201,0.12)', 0.4, -1);
  speechRings(c, 900, 690, 50, 2, t + 1.1, 'rgba(247,233,201,0.10)', 0.35, 1);
  dust(c, t, { n: 16, seed: 59, a: 0.22, y0: 340, y1: 1040, drift: 18 });
  glint(c, o, t, 0.12, 0.04);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE V · THE DEAFENING DARK');
  fig(c, 'FIG. 05 — NIGHT · 1,000,000 VOICES', 1372, { dark: true });
  tag(c, 'ALL AT ONCE', COL.ivory, clamp((t - wd(4, 6).s) / 0.25), TAG_Y);
  subs(c, 4, t);
  badge(c, t);
  c.restore();
}

// ── S06 · THE WITNESS AT THE PODIUM ─────────────────────────────────────────────────────────────
function scenePodium(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 6.8);
  const wall = c.createLinearGradient(0, o.y, 0, 980);
  wall.addColorStop(0, '#8C6A4A'); wall.addColorStop(1, '#4A3A2A');
  c.fillStyle = wall; c.fillRect(o.x, o.y, o.w, o.h);
  hatching(c, o.x, o.y, o.w, 620, 34, 0.06);
  sweep(c, 280, 700, t, 0.06, 0.2);
  c.fillStyle = '#3A2C22'; c.fillRect(o.x, 980, o.w, o.y + o.h - 980);
  floorPlanks(c, o.x, o.x + o.w, 1010, o.y + o.h, 72, 0.045);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.beginPath(); c.moveTo(o.x, 980); c.lineTo(o.x + o.w, 980); c.stroke();
  // the shadow on the wall, with one eye that never blinks
  const rotS = Math.sin(t * 1.7) * 0.018 + Math.sin(t * 0.8) * 0.008;
  wallShadow(c, 656 + sw(t, 1.15) * 4, 1000, 1.58 + sw(t, 1.6) * 0.012, rotS, 'stand', t, { a: 0.74, col: '#17110C', hat: true, mouth: false, rings: false });
  const hx = 656 + 192 * 1.55 * 1.58 * Math.sin(rotS);
  const hy = 1000 - 192 * 1.55 * 1.58 * Math.cos(rotS);
  const look = sw(t, 1.25) * 3.5;
  c.save();
  c.fillStyle = COL.ivory; c.beginPath(); c.ellipse(hx, hy - 24, 30, 18 + sw(t, 2.2) * 0.8, 0, 0, TAU); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.stroke();
  c.fillStyle = COL.shadow; circ(c, hx + 5 + look, hy - 24, 9); c.fill();
  c.fillStyle = COL.ivory; circ(c, hx + 7 + look, hy - 28, 2.8); c.fill();
  // the mouth, working around the words
  const mw = 24 + 3 * Math.abs(sw(t, 5.2)), mh = 12 + 5 * Math.abs(sw(t, 7.7, 1));
  c.fillStyle = COL.ivory; c.beginPath(); c.ellipse(hx + 2, hy + 30, mw, mh, 0, 0, TAU); c.fill();
  c.fillStyle = COL.shadow; c.beginPath(); c.ellipse(hx + 2, hy + 30, mw * 0.66, mh * 0.42, 0, 0, TAU); c.fill();
  c.restore();
  speechRings(c, hx + 44, hy + 30, 36, 4, t, 'rgba(247,233,201,0.75)', 0.7, 1);
  // the speaker, standing behind the podium
  c.save(); c.translate(460, 1020 - Math.abs(sw(t, 1.1)) * 2.5); c.rotate(sw(t, 0.85) * 0.008);
  person(c, 0, 0, 1.42, { pose: 'stand', rim: true });
  c.restore();
  // podium, in front of the speaker
  c.fillStyle = COL.wood; rr(c, 300, 880, 320, 160, 5); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 4; rr(c, 300, 880, 320, 160, 5); c.stroke();
  c.fillStyle = COL.woodD; rr(c, 284, 862, 352, 30, 4); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 3; c.stroke();
  c.strokeStyle = 'rgba(250,247,240,0.18)'; c.lineWidth = 2;
  for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(330 + i * 72, 902); c.lineTo(330 + i * 72, 1040); c.stroke(); }
  c.save(); c.globalAlpha = 0.3; sweep(c, 862, 178, t, 0.16, 0.7); c.restore();
  // a single podium microphone, angled at the speaker
  c.save(); c.translate(sw(t, 2.1) * 2, sw(t, 1.6) * 1.5);
  c.strokeStyle = COL.ink; c.lineWidth = 5; c.lineCap = 'round';
  c.beginPath(); c.moveTo(352, 878); c.lineTo(352, 822); c.stroke();
  c.beginPath(); c.moveTo(352, 822); c.lineTo(368, 810); c.stroke();
  c.fillStyle = COL.iron; circ(c, 372, 806, 12); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2.4; c.stroke();
  c.fillStyle = `rgba(247,233,201,${0.12 + 0.14 * Math.abs(sw(t, 3.4))})`; circ(c, 368, 802, 3.6); c.fill();
  c.fillStyle = COL.iron; rr(c, 340, 872, 24, 10, 3); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2.2; c.stroke();
  c.restore();
  // audience, each one breathing
  for (let i = 0; i < 7; i++) {
    const x = 140 + i * 132, y = 1140 + (i % 2) * 10 + sw(t, 1.4, i * 1.7) * 2.5;
    c.fillStyle = COL.ink; circ(c, x, y - 34, 22); c.fill();
    c.beginPath(); c.moveTo(x - 44, y); c.quadraticCurveTo(x, y - 44 - sw(t, 1.8, i) * 2, x + 44, y); c.closePath(); c.fill();
  }
  dust(c, t, { n: 20, seed: 71, a: 0.34, y0: 330, y1: 1120 });
  glint(c, o, t, 0.33, 0.055);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE VI · THE WITNESS');
  fig(c, 'FIG. 06 — TESTIMONY · NEVER BLINKS', 1372, { dark: true });
  tag(c, 'EVERY LIE', COL.ivory, clamp((t - wd(5, 1).s) / 0.25), TAG_Y);
  subs(c, 5, t);
  badge(c, t);
  c.restore();
}

// ── S07 · THE UNSEEN SELF ───────────────────────────────────────────────────────────────────────
function sceneSolitude(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 8.1);
  const wall = c.createLinearGradient(0, o.y, 0, 1000);
  wall.addColorStop(0, '#B99A78'); wall.addColorStop(1, '#7A5A3E');
  c.fillStyle = wall; c.fillRect(o.x, o.y, o.w, o.h);
  for (let i = 0; i < 16; i++) {
    c.strokeStyle = `rgba(92,82,72,${0.08 + (i % 3) * 0.025})`; c.lineWidth = 2;
    c.beginPath(); c.moveTo(o.x + 30 + i * 56 + sw(t, 0.6, i) * 1.2, o.y); c.lineTo(o.x + 30 + i * 56 + sw(t, 0.6, i + 1) * 1.2, 960); c.stroke();
  }
  sweep(c, 300, 660, t, 0.05, 0.42);
  // the shadow that answers, already on the wall behind everything
  wallShadow(c, 690 + sw(t, 1.2) * 4, 1000, 1.2 + sw(t, 1.7) * 0.012, -0.02 + sw(t, 1.3) * 0.02, 'sit', t, { a: 0.7, ringDx: 26, r0: 28, rn: 4, ringA: 0.75, ringCol: 'rgba(247,233,201,0.8)' });
  c.fillStyle = COL.woodD; c.fillRect(o.x, 960, o.w, o.y + o.h - 960);
  floorPlanks(c, o.x, o.x + o.w, 990, o.y + o.h, 70, 0.05);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.beginPath(); c.moveTo(o.x, 960); c.lineTo(o.x + o.w, 960); c.stroke();
  // window with night
  c.fillStyle = COL.night; c.fillRect(150, 380, 210, 300);
  c.strokeStyle = COL.ink; c.lineWidth = 5; c.strokeRect(150, 380, 210, 300);
  c.strokeStyle = COL.wood; c.lineWidth = 5;
  c.beginPath(); c.moveTo(255, 380); c.lineTo(255, 680); c.stroke();
  c.beginPath(); c.moveTo(150, 530); c.lineTo(360, 530); c.stroke();
  moon(c, 318, 450 + sw(t, 1.1) * 2, 30);
  for (let i = 0; i < 6; i++) {
    c.fillStyle = `rgba(247,233,201,${0.35 + 0.6 * Math.abs(Math.sin(t * (1.3 + i * 0.27) + i * 1.9))})`;
    circ(c, 176 + (i * 37) % 150, 414 + (i * 53) % 100, 1.7); c.fill();
  }
  // desk
  c.fillStyle = COL.wood; rr(c, 170, 820, 560, 34, 4); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 3.4; c.stroke();
  c.fillStyle = COL.woodD; c.fillRect(206, 854, 22, 120); c.fillRect(672, 854, 22, 120);
  c.strokeStyle = COL.ink; c.lineWidth = 2.4; c.strokeRect(206, 854, 22, 120); c.strokeRect(672, 854, 22, 120);
  // chair, rocking almost imperceptibly
  c.save(); c.translate(440, 980); c.rotate(sw(t, 1.35) * 0.006); c.translate(-440, -980);
  c.strokeStyle = COL.ink; c.lineWidth = 7; c.lineCap = 'round';
  c.beginPath(); c.moveTo(410, 980); c.lineTo(410, 860); c.stroke();
  c.beginPath(); c.moveTo(470, 980); c.lineTo(470, 860); c.stroke();
  c.beginPath(); c.moveTo(410, 892); c.lineTo(470, 892); c.stroke();
  c.fillStyle = COL.wood; rr(c, 392, 846, 96, 18, 3); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2.6; c.stroke();
  c.restore();
  // the person, seen from behind, breathing
  c.save(); c.translate(0, sw(t, 1.5) * 2.2);
  person(c, 438, 962, 1.0, { pose: 'sit', rim: false, hat: false });
  c.fillStyle = COL.ink; circ(c, 438, 770, 30); c.fill();
  c.fillStyle = COL.ink; c.beginPath(); c.ellipse(438, 800 + sw(t, 1.5, 1) * 0.6, 34, 20, 0, 0, TAU); c.fill();
  c.restore();
  // lamp, guttering
  c.fillStyle = COL.cream; poly(c, [742, 820, 822, 820, 806, 780, 758, 780]); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2.6; c.stroke();
  c.strokeStyle = COL.ink; c.lineWidth = 4; c.beginPath(); c.moveTo(782, 820); c.lineTo(782, 854); c.stroke();
  glow(c, 782, 800, 128 + sw(t, 2.9) * 8, COL.cream, 0.3 + 0.12 * Math.abs(sw(t, 2.3)));
  // letter and pen
  c.save(); c.translate(600, 810 + sw(t, 2.2) * 1.6); c.rotate(-0.08 + sw(t, 1.9) * 0.02);
  c.fillStyle = COL.ivory; rr(c, -54, -20, 108, 40, 2); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 1.6; rr(c, -54, -20, 108, 40, 2); c.stroke();
  c.strokeStyle = 'rgba(92,82,72,0.55)'; c.lineWidth = 1.4;
  for (let i = 0; i < 3; i++) { c.beginPath(); c.moveTo(-42, -10 + i * 10); c.lineTo(36, -10 + i * 10); c.stroke(); }
  c.restore();
  c.save(); c.translate(676, 806); c.rotate(-0.5 + sw(t, 2.6) * 0.07);
  c.strokeStyle = COL.brassD; c.lineWidth = 3.2; c.lineCap = 'round';
  c.beginPath(); c.moveTo(0, 0); c.lineTo(30, 0); c.stroke();
  c.strokeStyle = COL.ink; c.lineWidth = 1.2; c.beginPath(); c.moveTo(30, 0); c.lineTo(38, 0); c.stroke();
  c.restore();
  dust(c, t, { n: 26, seed: 83, a: 0.45, y0: 340, y1: 1120, drift: 10 });
  glint(c, o, t, 0.72, 0.05);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE VII · THE UNSEEN SELF');
  fig(c, 'FIG. 07 — SOLITUDE · PLAYBACK', 1372, { dark: true });
  tag(c, 'NO ONE IS THERE', COL.ivory, clamp((t - wd(6, 10).s) / 0.25), TAG_Y);
  subs(c, 6, t);
  badge(c, t);
  c.restore();
}

// ── S08 · THE TURN ──────────────────────────────────────────────────────────────────────────────
function sceneTurn(c, lt, t) {
  c.save();
  const o = stage();
  c.save(); c.scale(SS, SS); c.translate(-o.x, -o.y);
  c.save(); rr(c, o.x, o.y, o.w, o.h, 1); c.clip();
  c.save(); camera(c, o, lt, t, 9.4);
  const wall = c.createLinearGradient(0, o.y, 0, 1000);
  wall.addColorStop(0, '#4A3A2A'); wall.addColorStop(0.7, '#2B1F17'); wall.addColorStop(1, '#17120E');
  c.fillStyle = wall; c.fillRect(o.x, o.y, o.w, o.h);
  hatching(c, o.x, o.y, o.w, 760, 30, 0.06);
  // doorway, breathing light from the other side
  c.fillStyle = '#1C1712'; c.fillRect(128, 430, 210, 570);
  c.strokeStyle = COL.ink; c.lineWidth = 6; c.strokeRect(128, 430, 210, 570);
  c.strokeStyle = COL.wood; c.lineWidth = 4; c.strokeRect(140, 442, 186, 546);
  const dgA = 0.13 + 0.05 * Math.abs(sw(t, 2.6));
  const dg = c.createLinearGradient(128, 430, 338, 1000);
  dg.addColorStop(0, `rgba(247,233,201,${dgA})`); dg.addColorStop(1, 'rgba(247,233,201,0)');
  c.fillStyle = dg; c.fillRect(128, 430, 210, 570);
  c.fillStyle = `rgba(247,233,201,${0.05 + 0.03 * Math.abs(sw(t, 1.8, 1))})`; c.fillRect(140, 442, 186, 546);
  // floor
  c.fillStyle = '#241C16'; c.fillRect(o.x, 1000, o.w, o.y + o.h - 1000);
  floorPlanks(c, o.x, o.x + o.w, 1030, o.y + o.h, 74, 0.04);
  c.strokeStyle = COL.ink; c.lineWidth = 3; c.beginPath(); c.moveTo(o.x, 1000); c.lineTo(o.x + o.w, 1000); c.stroke();
  // lamp light from the right
  const lgA = 0.3 + 0.08 * Math.abs(sw(t, 2.2));
  const lg = c.createRadialGradient(850, 760, 20, 850, 760, 360 + sw(t, 1.6) * 14);
  lg.addColorStop(0, `rgba(247,233,201,${lgA})`); lg.addColorStop(1, 'rgba(247,233,201,0)');
  c.fillStyle = lg; circ(c, 850, 760, 380); c.fill();
  // the turner, mid-turn
  c.save(); c.translate(446, 1040 - Math.abs(sw(t, 1.4)) * 2); c.rotate(sw(t, 1.1) * 0.02);
  person(c, 0, 0, 1.45, { pose: 'turn', rim: true });
  c.restore();
  // the voice behind
  wallShadow(c, 712 + sw(t, 1.25) * 4, 1020, 1.5 + sw(t, 1.7) * 0.012, -0.03 + sw(t, 1.4) * 0.022, 'turn', t, { a: 0.68, hat: true, ringDx: 34, r0: 38, rn: 5, ringA: 0.9, ringCol: 'rgba(247,233,201,0.9)' });
  // a clock at 11:59, ticking
  c.save(); c.translate(862 + sw(t, 1.2) * 2, 510 + sw(t, 1.5) * 2);
  c.fillStyle = 'rgba(43,31,23,0.25)'; circ(c, 4, 6, 58); c.fill();
  c.fillStyle = brassGrad(c, -58, -58, 58, 58); circ(c, 0, 0, 58); c.fill();
  c.strokeStyle = COL.ink; c.lineWidth = 3.4; circ(c, 0, 0, 58); c.stroke();
  c.fillStyle = COL.ivory; circ(c, 0, 0, 48); c.fill(); c.strokeStyle = COL.ink; c.lineWidth = 2; c.stroke();
  for (let i = 0; i < 12; i++) {
    const a = i * TAU / 12;
    c.strokeStyle = COL.ink; c.lineWidth = i % 3 === 0 ? 3 : 1.4;
    c.beginPath(); c.moveTo(Math.cos(a) * 36, Math.sin(a) * 36); c.lineTo(Math.cos(a) * 44, Math.sin(a) * 44); c.stroke();
  }
  c.strokeStyle = COL.ink; c.lineWidth = 4; c.lineCap = 'round';
  c.beginPath(); c.moveTo(0, 0); c.lineTo(-12, -30); c.stroke();
  c.beginPath(); c.moveTo(0, 0); c.lineTo(2, -40); c.stroke();
  tickClock(c, 0, 0, 48, t, 1);
  c.fillStyle = COL.terra; circ(c, 0, 0, 4); c.fill();
  c.restore();
  // the threshold, its dashes marching
  c.strokeStyle = `rgba(200,157,66,${0.4 + 0.25 * Math.abs(sw(t, 2.4))})`; c.lineWidth = 2; c.setLineDash([8, 12]); c.lineDashOffset = -t * 30;
  c.beginPath(); c.moveTo(338, 1000); c.lineTo(338, 520); c.stroke(); c.setLineDash([]);
  dust(c, t, { n: 22, seed: 97, a: 0.35, y0: 340, y1: 1130, drift: 8 });
  glint(c, o, t, 0.58, 0.05);
  c.restore();
  c.restore();
  c.restore();
  foot(c);
  plateTag(c, 'PLATE VIII · THE TURN');
  fig(c, 'FIG. 08 — PROXIMITY · LISTEN', 1372, { dark: true });
  tag(c, 'BEHIND YOU', COL.ivory, clamp((t - wd(7, 8).s) / 0.25), TAG_Y);
  subs(c, 7, t);
  badge(c, t);
  c.restore();
}

// ── S09 · THE TITLE CARD (the question, spoken once, at the end) ────────────────────────────────
function titleCard(c, lt, t) {
  bg(c);
  c.save();
  c.translate(sw(t, 0.55) * 3, sw(t, 0.7) * 2.5);
  c.save();
  c.strokeStyle = 'rgba(92,82,72,0.14)'; c.lineWidth = 2;
  c.beginPath(); c.arc(540, 1080, 420, 0, TAU); c.stroke();
  c.translate(540, 1080); c.rotate(t * 0.055);
  c.setLineDash([8, 14]); c.strokeStyle = 'rgba(200,157,66,0.28)'; c.lineWidth = 2.2;
  c.beginPath(); c.arc(0, 0, 372, 0, TAU); c.stroke(); c.setLineDash([]);
  c.restore();
  for (let i = 0; i < 48; i++) {
    const a = i * TAU / 48, long = i % 4 === 0;
    const len = (long ? 16 : 9) + 2.5 * Math.abs(sw(t, 1.7, i * 0.4));
    c.strokeStyle = long ? 'rgba(92,82,72,0.28)' : 'rgba(92,82,72,0.13)'; c.lineWidth = long ? 2.4 : 1.6;
    c.beginPath(); c.moveTo(540 + Math.cos(a) * 420, 1080 + Math.sin(a) * 420);
    c.lineTo(540 + Math.cos(a) * (420 + len), 980 + Math.sin(a) * (420 + len)); c.stroke();
  }
  const kin = eo(clamp(lt / 0.5));
  const ty = (1 - kin) * 14;
  c.strokeStyle = 'rgba(92,82,72,0.22)'; c.lineWidth = 2.2;
  c.beginPath(); c.moveTo(70, 1284 + ty); c.bezierCurveTo(260, 1272 + ty, 380, 1288 + ty, 540, 1282 + ty);
  c.bezierCurveTo(720, 1276 + ty, 880, 1288 + ty, 1010, 1278 + ty); c.stroke();
  txt(c, 'THOUGHT EXPERIMENT · No. 10', 540, 238, { size: 19, fam: F.mono, weight: 700, col: COL.terra, ls: 5.2 });
  const s1 = fit(c, 'What if shadows', 940, 180, F.serif, 400, 'italic');
  txt(c, 'What if shadows', 540, 378 + ty, { size: s1, fam: F.serif, weight: 400, style: 'italic', ls: -1.5 });
  const s2 = fit(c, 'could speak?', 940, 192, F.serif, 400, 'italic');
  txt(c, 'could speak?', 540, 552 + ty, { size: s2, fam: F.serif, weight: 400, style: 'italic', ls: -1.5 });
  const fullW = tw(c, 'could speak?', s2, F.serif, 400, 'italic', -1.5);
  const couldW = tw(c, 'could ', s2, F.serif, 400, 'italic', -1.5);
  const speakW = tw(c, 'speak', s2, F.serif, 400, 'italic', -1.5);
  const ux = 540 - fullW / 2 + couldW;
  const k = clamp((lt - 0.14) / (4 / 24));
  if (k > 0) {
    const uk = clamp(eback(k), 0, 1);
    c.save(); c.globalAlpha = clamp(k * 1.4); c.fillStyle = COL.terra;
    rr(c, ux + (speakW - speakW * uk) / 2, 630 + ty, Math.max(0, speakW * uk), 11, 5); c.fill();
    c.fillStyle = rgba(COL.terra, 0.34);
    rr(c, ux + 18, 650 + ty, Math.max(0, speakW - 36), 3, 1.5); c.fill();
    const gp = (t * 0.5) % 1;
    if (uk > 0.2) {
      const gx = ux + speakW * gp;
      const gg = c.createLinearGradient(gx - 30, 0, gx + 30, 0);
      gg.addColorStop(0, 'rgba(255,250,235,0)'); gg.addColorStop(0.5, 'rgba(255,250,235,0.55)'); gg.addColorStop(1, 'rgba(255,250,235,0)');
      c.fillStyle = gg; c.fillRect(ux, 630 + ty, speakW, 11);
    }
    c.restore();
  }
  // the caster and the shadow that finally speaks
  c.save(); c.strokeStyle = 'rgba(194,89,63,0.35)'; c.lineWidth = 2; c.setLineDash([6, 11]);
  c.lineDashOffset = -t * 22;
  c.beginPath(); c.moveTo(292, 1330); c.quadraticCurveTo(460, 1350 + sw(t, 1.3) * 3, 610, 1324); c.stroke(); c.setLineDash([]); c.restore();
  c.save(); c.translate(292, 1330 - Math.abs(sw(t, 1.2)) * 2); c.rotate(sw(t, 0.8) * 0.008);
  person(c, 0, 0, 0.95, { pose: 'stand', rim: false });
  c.restore();
  wallShadow(c, 610 + sw(t, 1.2) * 4, 1324, 1.08 + sw(t, 1.6) * 0.01, -0.02 + sw(t, 1.35) * 0.02, 'stand', t, { a: 0.8, hat: true, ringDx: 28, r0: 30, rn: 4, ringA: 0.9, ringCol: 'rgba(194,89,63,0.7)' });
  txt(c, 'FIG. 09 — SHADOW · SPEECH', 540, 1470, { size: 19, fam: F.mono, weight: 500, col: COL.sepia, ls: 2.2 });
  sweep(c, 200, 940, t, 0.055, 0.18);
  dust(c, t, { n: 18, seed: 109, a: 0.3, y0: 200, y1: 1120, drift: 9 });
  c.restore();
  c.save(); c.globalAlpha = 0.62;
  c.save(); c.translate(948, 238); c.rotate(t * 0.7);
  c.strokeStyle = 'rgba(92,82,72,0.35)'; c.lineWidth = 1.4; c.setLineDash([3, 5]);
  c.beginPath(); c.arc(0, 0, 23, 0, TAU); c.stroke(); c.setLineDash([]); c.restore();
  loopMark(c, 948, 238, 16, COL.sepia, 1);
  txt(c, 'LOOP 10', 948, 272, { size: 18, fam: F.mono, weight: 500, col: COL.sepia, ls: 2.2 });
  c.restore();
  badge(c, t);
}

// ── the film ────────────────────────────────────────────────────────────────────────────────────
const SHOT1 = {
  id: 'S01', at: 0, note: 'cold open · the witness',
  draw(c, V, lt, t) { sceneWitness(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.05, vig: 0.18, grain: 0.05 },
};
const SHOT2 = {
  id: 'S02', at: 0, note: 'the echo · half a second late',
  draw(c, V, lt, t) { sceneEcho(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.045, vig: 0.19, grain: 0.05 },
};
const SHOT3 = {
  id: 'S03', at: 0, note: 'the noon parley · shadows in conference',
  draw(c, V, lt, t) { sceneParley(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.04, vig: 0.18, grain: 0.05 },
};
const SHOT4 = {
  id: 'S04', at: 0, note: 'the heirloom · still talking',
  draw(c, V, lt, t) { sceneHeirloom(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.05, vig: 0.2, grain: 0.05 },
};
const SHOT5 = {
  id: 'S05', at: 0, note: 'the deafening dark · a million voices',
  draw(c, V, lt, t) { sceneNight(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.04, vig: 0.2, grain: 0.05 },
};
const SHOT6 = {
  id: 'S06', at: 0, note: 'the witness at the podium · never blinks',
  draw(c, V, lt, t) { scenePodium(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.045, vig: 0.19, grain: 0.05 },
};
const SHOT7 = {
  id: 'S07', at: 0, note: 'the unseen self · no one is there',
  draw(c, V, lt, t) { sceneSolitude(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.04, vig: 0.19, grain: 0.05 },
};
const SHOT8 = {
  id: 'S08', at: 0, note: 'the turn · listen for the voice',
  draw(c, V, lt, t) { sceneTurn(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.05, vig: 0.2, grain: 0.05 },
};
const SHOT9 = {
  id: 'S09', at: 0, end: 34.0, note: 'title card · the question',
  draw(c, V, lt, t) { titleCard(c, lt, t); },
  look: { tint: COL.amber, tintA: 0.05, vig: 0.18, grain: 0.05 },
};

export function buildShots() {
  const S2 = cut(1, 0), S3 = cut(2, 0), S4 = cut(3, 0), S5 = cut(4, 0);
  const S6 = cut(5, 0), S7 = cut(6, 0), S8 = cut(7, 0), S9 = cut(9, 0);
  SHOT2.at = S2; SHOT3.at = S3; SHOT4.at = S4; SHOT5.at = S5;
  SHOT6.at = S6; SHOT7.at = S7; SHOT8.at = S8; SHOT9.at = S9;
  SHOT1.cues = [[0.10, 'whoosh', { gain: 0.55 }], [wd(0, 4).s, 'click', { gain: 0.30 }], [wd(0, 5).s, 'hum', { dur: 1.6, gain: 0.28 }], [wd(0, 6).s, 'step', { gain: 0.40 }]];
  SHOT2.cues = [[S2 + 0.12, 'click', { gain: 0.22 }], [wd(1, 10).s, 'blip', { gain: 0.34 }], [wd(1, 18).s, 'squeak', { gain: 0.28 }], [wd(1, 21).s, 'blip', { gain: 0.30 }]];
  SHOT3.cues = [[S3 + 0.10, 'click', { gain: 0.20 }], [wd(2, 0).s, 'step', { gain: 0.30 }], [wd(2, 9).s, 'paper', { dur: 0.8, gain: 0.30 }], [wd(2, 11).s, 'blip', { gain: 0.26 }]];
  SHOT4.cues = [[S4 + 0.10, 'click', { gain: 0.20 }], [wd(3, 2).s, 'hum', { dur: 2.0, gain: 0.34 }], [wd(3, 6).s, 'knock', { gain: 0.30 }], [wd(3, 8).s, 'land', { gain: 0.32 }]];
  SHOT5.cues = [[S5 + 0.10, 'click', { gain: 0.20 }], [wd(4, 2).s, 'night', { dur: 2.6, gain: 0.42 }], [wd(4, 4).s, 'hum', { dur: 2.2, gain: 0.30 }], [wd(4, 9).s, 'swell', { dur: 1.8, gain: 0.34 }]];
  SHOT6.cues = [[S6 + 0.10, 'click', { gain: 0.20 }], [wd(5, 2).s, 'thud', { gain: 0.34 }], [wd(5, 5).s, 'blip', { gain: 0.28 }], [wd(5, 8).s, 'click', { gain: 0.26 }]];
  SHOT7.cues = [[S7 + 0.10, 'click', { gain: 0.20 }], [wd(6, 0).s, 'paper', { dur: 0.9, gain: 0.28 }], [wd(6, 5).s, 'hum', { dur: 2.0, gain: 0.30 }], [wd(6, 10).s, 'blip', { gain: 0.26 }]];
  SHOT8.cues = [[S8 + 0.10, 'click', { gain: 0.22 }], [wd(7, 5).s, 'step', { gain: 0.42 }], [wd(7, 7).s, 'whoosh', { gain: 0.38 }], [wd(7, 8).s, 'hum', { dur: 2.4, gain: 0.34 }], [29.30, 'swell', { dur: 1.8, gain: 0.30 }]];
  SHOT9.cues = [[wd(9, 2).s, 'click', { gain: 0.28 }], [wd(9, 3).s, 'land', { gain: 0.46 }], [wd(9, 3).s + 1.0, 'swell', { dur: 1.8, gain: 0.30 }]];
  return [SHOT1, SHOT2, SHOT3, SHOT4, SHOT5, SHOT6, SHOT7, SHOT8, SHOT9];
}
